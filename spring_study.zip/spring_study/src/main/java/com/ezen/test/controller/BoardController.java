package com.ezen.test.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ezen.test.domain.BoardVO;
import com.ezen.test.service.BoardService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Controller
@RequestMapping("/board/*")
@Slf4j
public class BoardController {
    private final BoardService bsv;

    @GetMapping("/register")
    public String register() {
        return "/board/register";
    }

    @PostMapping("/insert")
    public String insert(BoardVO bvo) {
        log.info(">>>> bvo >> {}", bvo);

        int isOk = bsv.insert(bvo);
        return "/";
    }
}

